# -*- coding: utf-8 -*-

from odoo import api, fields, models, Command, _

class AccountMove(models.Model):
    _name = "account.move"

    def _synchronize_business_models(self, changed_fields):
        return True