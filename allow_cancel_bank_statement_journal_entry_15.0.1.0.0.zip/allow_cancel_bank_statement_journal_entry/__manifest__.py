#-*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Block Synchronize Business Models',
    'category': 'Account',
    'version': '15.0.1.0.0',
    'author': 'Bipin Prajapati',
    'summary': 'Block Synchronize Business Models',
    'description': "",
    'depends': [
        'account'
    ],
    'data': [

    ],
}
