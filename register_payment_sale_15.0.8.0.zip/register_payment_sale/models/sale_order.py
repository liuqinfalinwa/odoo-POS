from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class GlobalChannel(models.Model):
    _name = 'global.channel.ept'
    _description = 'Global Channel'

    name = fields.Char('Global Channel')
    if_offline = fields.Boolean('Payment Request Required')


class SaleOrderType(models.Model):
    _name = "sale.type"
    name = fields.Char('Type')
    payment_request_required = fields.Boolean('Payment Request Required?')


class SaleOrder(models.Model):
    _inherit = "sale.order"

    battery = fields.Boolean("battery")
    advance_account_payment_ids = fields.Many2many('account.payment', string='Advance Payments', copy=False)
    advance_payment_count = fields.Integer('Advance Payment Count', compute='advance_payment', copy=False, store=True)
    total_register_payment = fields.Monetary('Total Registered Amount', compute='_get_total_register_payment',
                                             store=True, copy=False)
    total_request_amount = fields.Monetary('Total Requested Amount', compute='_get_total_register_payment',
                                             store=True, copy=False)
    payment_amount = fields.Monetary('Request Amount', copy=False)
    due_amount = fields.Monetary('Due Amount', compute='_get_total_register_payment', store=True, copy=False)
    x_studio_finance_appoved = fields.Boolean('Finance Approved', tracking=True, copy=False)
    x_studio_delivery_payments_required = fields.Boolean('Is Delivery Payment Required?', related='payment_term_id.x_studio_delivery_payments_required')
    x_studio_type = fields.Many2one('sale.type', 'Type')
    payment_request_required = fields.Boolean('Payment Request Required?', related='x_studio_type.payment_request_required')
    global_channel_id = fields.Many2one('global.channel.ept', string='Global Channel')
    if_offline = fields.Boolean('Is Offline?', related='global_channel_id.if_offline')
    is_any_picking_done = fields.Boolean('Is Any Picking Done', compute='_get_picking_done', store=True)


    @api.depends('picking_ids', 'picking_ids.state')
    def _get_picking_done(self):
        for rec in self:
            if any(rec.picking_ids.filtered(lambda picking: picking.state in ('done'))):
                rec.is_any_picking_done = True
            else:
                rec.is_any_picking_done = False

    def action_cancel_payment_sale_order(self):
        for rec in self:
            for payment in rec.advance_account_payment_ids:
                if payment.state == 'posted':
                    payment.action_cancel()
                if payment.state == 'draft':
                    payment.action_cancel()

    def action_finance_approved(self):
        for rec in self:
            rec.x_studio_finance_appoved = True
            payment_rec = self.env['sale.order.payment'].search([('sale_order_id', '=', rec._origin.id)])
            if payment_rec:
                self.env['mail.message'].create({
                    'body': "Finance Approved -> True " + rec.name,
                    'model': 'account.payment',
                    'res_id': payment_rec[0].payment_id.id,
                })

    def action_finance_reject(self):
        for rec in self:
            rec.x_studio_finance_appoved = False
            payment_rec = self.env['sale.order.payment'].search([('sale_order_id', '=', rec._origin.id)])
            if payment_rec:
                self.env['mail.message'].create({
                    'body': "Finance Approved -> False " + rec.name,
                    'model': 'account.payment',
                    'res_id': payment_rec[0].payment_id.id,
                })

    # @api.onchange('x_studio_finance_appoved')
    # def onchange_x_studio_finance_appoved(self):
    #     for rec in self:
    #         if rec.x_studio_finance_appoved:
    #             payment_rec = self.env['sale.order.payment'].search([('sale_order_id','=',rec._origin.id)])
    #             if payment_rec:
    #                 self.env['mail.message'].create({
    #                     'body': "Finance Approved -> True " + rec.name,
    #                     'model': 'account.payment',
    #                     'res_id': payment_rec[0].payment_id.id,
    #                 })
    #         else:
    #             payment_rec = self.env['sale.order.payment'].search([('sale_order_id', '=', rec._origin.id)])
    #             if payment_rec:
    #                 self.env['mail.message'].create({
    #                     'body': "Finance Approved -> False " + rec.name,
    #                     'model': 'account.payment',
    #                     'res_id': payment_rec[0].payment_id.id,
    #                 })



    @api.depends('advance_account_payment_ids', 'advance_account_payment_ids.state', 'advance_account_payment_ids.sale_order_ids', 'order_line')
    def _get_total_register_payment(self):
        for rec in self:
            sale_order_payment_ids = self.env['sale.order.payment'].search([('sale_order_id', '=', rec.id)])
            total_register_payment = 0
            total_request_amount = 0
            for payment_order in sale_order_payment_ids:
                if payment_order.payment_id.state in ['posted', 'reconciled']:
                    total_register_payment += payment_order.register_amount
                if payment_order.payment_id.state in ['draft']:
                    total_request_amount += payment_order.request_amount
            rec.total_register_payment = total_register_payment
            rec.total_request_amount = total_request_amount
            rec.due_amount = rec.amount_total - total_register_payment

            # for payment in rec.advance_account_payment_ids:
            #     for payment_order in payment.sale_order_ids:
            #         if payment.state in ['posted', 'reconciled']:
            #             rec.total_register_payment += payment_order.request_amount
            #         if payment.state in ['draft']:
            #             rec.total_request_amount += payment_order.payment_order
            # rec.due_amount = rec.amount_total - rec.total_register_payment


    def action_advance_payment_sale_order(self):
        # active_ids = self.env.context.get('active_ids', [])
        # print("aaaaaaaaaaaaaaaaaaaaaaaaaaa", active_ids)
        list_order = []
        for order_id in self:
            sale_order_wizard_id = self.env['sale.order.wizard'].create({
                'sale_order_id': order_id.id
            })
            list_order.append(sale_order_wizard_id.id)

        view_id = self.env.ref('register_payment_sale.view_advance_payment_dorsan').id
        return {
            'name': _('Sale Order Payment Request'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'advance.payment.dorsan',
            'view_id': view_id,
            'views': [(view_id, 'form')],
            'target': 'new',
            'context': {
                'default_sale_order_ids': [(6, 0, list_order)],
            }
        }

    @api.depends('advance_account_payment_ids', 'advance_account_payment_ids.state')
    def advance_payment(self):
        for rec in self:
            rec._get_total_register_payment()
            rec.advance_payment_count = len(rec.advance_account_payment_ids.filtered(lambda payment: payment.state != 'cancelled'))

    def action_view_advance_payment(self):
        payments = self.mapped('advance_account_payment_ids')
        action = self.env.ref('account.action_account_payments').read()[0]
        action['context'] = {
                'default_payment_type': 'inbound',
                'default_partner_type': 'customer',
                # 'search_default_inbound_filter': 1,
                'res_partner_search_mode': 'customer',
            }
        if len(payments) > 1:
            action['domain'] = [('id', 'in', payments.ids)]
        elif len(payments) == 1:
            form_view = [(self.env.ref('account.view_account_payment_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = payments.id
        else:
            action = {'type': 'ir.actions.act_window_close'}
        return action

